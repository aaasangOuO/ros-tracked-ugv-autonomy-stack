// radar_obstacle_layer.h
#ifndef RADAR_OBSTACLE_LAYER_H_
#define RADAR_OBSTACLE_LAYER_H_

// 引入 ROS 核心头文件
#include <ros/ros.h>

// 引入 costmap_2d 中图层的相关类
#include <costmap_2d/layer.h>
#include <costmap_2d/layered_costmap.h>
#include <costmap_2d/observation_buffer.h>
#include <costmap_2d/obstacle_layer.h>
#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/costmap_math.h>

// 插件宏导出支持（用于注册插件）
#include <pluginlib/class_list_macros.h>

// 使用自定义的障碍物消息类型
#include <ObstacleArray.h>

namespace costmap_2d
{

/**
 * @brief RadarObstacleLayer 是一个自定义的 costmap 层插件
 *        用于将毫米波雷达检测到的障碍物集成到 ROS navigation 的代价地图中。
 */
class RadarObstacleLayer : public CostmapLayer
{
public:
    RadarObstacleLayer();  // 构造函数

    /**
     * @brief 初始化函数（ROS 加载插件时自动调用）
     *        通常用于获取参数、订阅话题、初始化变量等。
     */
    virtual void onInitialize();

    /**
     * @brief 更新代价地图时确定本层需要更新的边界范围
     * @param origin_x, origin_y, origin_yaw 当前机器人位姿
     * @param min_x, min_y, max_x, max_y 被更新的 costmap 范围（输出）
     */
    virtual void updateBounds(double origin_x, double origin_y, double origin_yaw,
                              double* min_x, double* min_y, double* max_x, double* max_y);

    /**
     * @brief 实际向 costmap 写入障碍物代价值
     * @param master_grid 主地图（即 LayeredCostmap 中的主 costmap）
     * @param min_i, min_j, max_i, max_j 待更新区域的索引范围
     */
    virtual void updateCosts(Costmap2D& master_grid, int min_i, int min_j, int max_i, int max_j);

    /**
     * @brief 重置该图层（清空障碍物列表等）
     */
    virtual void reset();

private:
    /**
     * @brief 订阅回调函数：接收来自毫米波雷达节点发布的 ObstacleArray 消息
     * @param msg 指向接收到的障碍物数组消息的智能指针
     */
    std::mutex data_mutex_;
    void matchSize();  ///< 将图层尺寸与主 costmap 匹配

    void obstacleCallback(const obstacle_avoidance::ObstacleArray::ConstPtr& msg);

    ros::Subscriber obstacle_sub_; ///< ROS 订阅器，用于订阅 "/obstacles" 障碍物消息

    std::vector<geometry_msgs::Point> obstacles_; ///< 保存最近一次接收到的障碍物点位置

    double obstacle_radius_; ///< 每个障碍物在 costmap 中膨胀的半径（单位：米）

    bool enabled_; ///< 图层是否启用的标志位，可用于动态启用/禁用该图层
};

} // namespace costmap_2d

#endif // RADAR_OBSTACLE_LAYER_H_
