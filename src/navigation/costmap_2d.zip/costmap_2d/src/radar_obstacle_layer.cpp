// 插件导出宏（必须在 .cpp 文件中注册插件）
#include <pluginlib/class_list_macros.h>

// Costmap 插件依赖头文件
#include <costmap_2d/costmap_layer.h>
#include <costmap_2d/layered_costmap.h>
#include "radar_obstacle_layer.h"

// RadarObstacleLayer 的头文件
#include <costmap_2d/radar_obstacle_layer.h>

// ROS 消息格式
#include <geometry_msgs/Point.h>
#include <obstacle_avoidance/ObstacleArray.h>

// 使用 costmap_2d 命名空间，简化后续调用
using namespace costmap_2d;

namespace costmap_2d
{

/**
 * @brief 初始化函数，在插件加载时由 ROS 自动调用
 *        包括话题订阅、变量初始化等操作
 */
void RadarObstacleLayer::onInitialize()
{
    // 创建专属的私有 NodeHandle（命名空间为 /move_base/你的图层名）
    ros::NodeHandle nh("~/" + name_);

    // 设置当前图层为“有效”（current = true 表示图层当前内容可用）
    current_ = true;

    // 订阅毫米波雷达发布的障碍物数组话题（ObstacleArray 类型）
    obstacle_sub_ = nh.subscribe("/obstacle_array", 1, &RadarObstacleLayer::obstacleCallback, this);

    // 设置该图层的默认代价值为 NO_INFORMATION（未指定）
    default_value_ = NO_INFORMATION;

    // 调整该图层的尺寸以匹配主 costmap 的尺寸
    matchSize();
}

/**
 * @brief 将该图层的大小与主 Costmap 对齐
 *        通常在初始化或重置时调用
 */
void RadarObstacleLayer::matchSize()
{
    // 获取主 costmap 的指针
    costmap_2d::Costmap2D* master = this->layered_costmap_->getCostmap();

    // 使用主地图的参数（分辨率、尺寸、原点）来调整本图层
    this->resizeMap(master->getSizeInCellsX(), master->getSizeInCellsY(),
                    master->getResolution(), master->getOriginX(), master->getOriginY());
}

/**
 * @brief 更新代价地图边界范围
 *        仅将障碍物所在区域标记为需更新区域，减少计算开销
 */
void RadarObstacleLayer::updateBounds(double origin_x, double origin_y, double origin_yaw,
                                      double* min_x, double* min_y, double* max_x, double* max_y)
{
    // 加锁防止与回调同时访问障碍物列表
    std::lock_guard<std::mutex> lock(data_mutex_);

    // 遍历每一个障碍物，更新地图最小和最大边界
    for (const auto& obs : obstacles_)
    {
        // 注意：此处使用 obs.width / 2 和 obs.length / 2，但 obs 实际为 geometry_msgs::Point
        // 若你的 Obstacle 类型中包含 width、length，请调整为使用 obs.xxx 而非 pt
        *min_x = std::min(*min_x, obs.x);
        *min_y = std::min(*min_y, obs.y);
        *max_x = std::max(*max_x, obs.x);
        *max_y = std::max(*max_y, obs.y);
    }
}

/**
 * @brief 实际向代价地图写入障碍物数据（设置为 LETHAL_OBSTACLE）
 */
void RadarObstacleLayer::updateCosts(Costmap2D& master_grid,
                                     int min_i, int min_j, int max_i, int max_j)
{
    // 加锁，防止线程冲突
    std::lock_guard<std::mutex> lock(data_mutex_);

    // 遍历所有障碍物，将其位置对应的地图格子设置为 LETHAL_OBSTACLE
    for (const auto& obs : obstacles_)
    {
        unsigned int mx, my;

        // 将世界坐标 (obs.x, obs.y) 转换为地图索引坐标 (mx, my)
        if (worldToMap(obs.x, obs.y, mx, my))
        {
            // 设置地图单元格的代价值为致命障碍
            master_grid.setCost(mx, my, LETHAL_OBSTACLE);
        }
    }
}

/**
 * @brief 接收障碍物消息的回调函数
 *        将接收到的 ObstacleArray 数据缓存到内部列表中
 */
void RadarObstacleLayer::obstacleCallback(const obstacle_avoidance::ObstacleArray::ConstPtr& msg)
{
    // 加锁以保证线程安全
    std::lock_guard<std::mutex> lock(data_mutex_);

    // 清除旧的障碍物点列表
    obstacles_.clear();

    // 遍历消息中的每个障碍物对象，提取其位置并存入内部列表
    for (const auto& obs : msg->Obstacles)
    {
        geometry_msgs::Point pt;
        pt.x = obs.x;
        pt.y = obs.y;
        pt.z = obs.z;
        obstacles_.push_back(pt);
    }
}

} // namespace costmap_2d

// 插件导出宏：将该类注册为 costmap_2d 的 Layer 插件
PLUGINLIB_EXPORT_CLASS(costmap_2d::RadarObstacleLayer, costmap_2d::Layer)
